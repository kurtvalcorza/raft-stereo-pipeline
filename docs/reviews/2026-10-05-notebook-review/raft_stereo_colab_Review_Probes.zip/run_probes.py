"""Review probes for raft_stereo_colab that need no torch and no checkpoint (numpy + pillow).

P3  disparity range of the rendered sample (32 pairs, seed 0) and of the 3 unseen pairs (seed 99): how much of
    the evaluated (valid) pixels lies in the 0-4 px range where the random-dot diagnostic failed.
P4  BYOD dataset reader + validation + split on constructed folders; the BYOD cell's _pick and _safe_unzip helpers.
"""
import io, json, sys, zipfile
from pathlib import Path
import numpy as np
from PIL import Image

repo, out = Path(sys.argv[1]), Path(sys.argv[2])
sys.path.insert(0, str(repo / "src"))
import raft_stereo_pipeline as P

res = {}
def disp_stats(records):
    vals = np.concatenate([r["disparity"][r["valid"]] for r in records])
    return {"pairs": len(records), "valid_pixels": int(vals.size), "min_px": round(float(vals.min()), 3),
            "p01_px": round(float(np.percentile(vals, 1)), 3), "median_px": round(float(np.median(vals)), 3),
            "share_below_2px": float((vals < 2).mean()), "share_below_4px": round(float((vals < 4).mean()), 4),
            "share_below_8px": round(float((vals < 8).mean()), 4)}
res["P3"] = {"SAMPLE_MIN_DISPARITY": P.samples.SAMPLE_MIN_DISPARITY if hasattr(P, "samples") else None,
             "dataset_seed0_32": disp_stats(P.stereo_dataset(32, seed=0)),
             "unseen_seed99_3": disp_stats(P.stereo_dataset(3, seed=99))}

def png(arr):
    b = io.BytesIO(); Image.fromarray(arr).save(b, "PNG"); return b.getvalue()
def make_folder(name, entries, files):
    d = out / name
    d.mkdir(parents=True, exist_ok=True)
    (d / "pairs.json").write_text(json.dumps(entries))
    for k, v in files.items():
        (d / k).parent.mkdir(parents=True, exist_ok=True)
        if isinstance(v, np.ndarray) and v.dtype == np.float32:
            np.save(d / k, v)
        else:
            (d / k).write_bytes(v)
    return d
rng = np.random.default_rng(0)
img = lambda w=128, h=96: png(rng.integers(0, 255, (h, w, 3), dtype=np.uint8))
disp = lambda w=128, h=96, v=5.0: np.full((h, w), v, dtype=np.float32)
def good(n=4, groups=True):
    entries, files = [], {}
    for i in range(n):
        e = {"left": f"l{i}.png", "right": f"r{i}.png", "disparity": f"d{i}.npy"}
        if groups: e["group"] = f"g{i % 2}"
        entries.append(e); files.update({f"l{i}.png": img(), f"r{i}.png": img(), f"d{i}.npy": disp()})
    return entries, files
cases = {}
cases["ok_4_two_groups"] = good()
e, f = good(); e[1]["left"] = "../outside/im1.png"; cases["traversal"] = (e, f)
e, f = good(); f["d0.npy"] = disp(v=-3.0); cases["negative_disparity"] = (e, f)
e, f = good(); del f["r2.png"]; cases["missing_file"] = (e, f)
e, f = good(); [x.update(group="g0") for x in e]; cases["one_group"] = (e, f)
e, f = good(); f["r1.png"] = img(120, 96); cases["size_mismatch"] = (e, f)
e, f = good(); f["d3.npy"] = disp(64, 48); cases["disparity_shape"] = (e, f)
e, f = good(); e[0]["disparity"] = "d0.txt"; f["d0.txt"] = b"5"; cases["unsupported_disparity_format"] = (e, f)
e, f = good(2, groups=False); cases["two_pairs_no_group"] = (e, f)
e, f = good(); f["l0.png"] = img(1400, 96); f["r0.png"] = img(1400, 96); f["d0.npy"] = disp(1400, 96); cases["too_wide"] = (e, f)
p4 = {}
for name, (entries, files) in cases.items():
    d = make_folder(name, entries, files)
    try:
        recs = P.read_stereo_records(d)
        man = P.validate_dataset(recs)
        tr, ho = P.split_dataset(recs, holdout=0.25, seed=20261004)
        p4[name] = {"accepted": True, "records": len(recs), "split": [len(tr), len(ho)]}
    except Exception as exc:
        p4[name] = {"accepted": False, "error": f"{type(exc).__name__}: {exc}"[:260]}
res["P4_dataset"] = p4

# the BYOD cell's helpers, exec'd from the notebook source
nb = json.loads((repo / "tutorials/raft_stereo_colab.ipynb").read_text())
cell = next("".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code" and "USE_BYOD_PAIR = False" in "".join(c["source"]))
ns = {"ROOT": out / "cellroot", "Path": Path}
exec(compile(cell, "byod_cell", "exec"), ns)  # both branches are off, so only definitions and the two prints run
pick = {}
for label, names in {"middlebury": ["im0.png", "im1.png", "disp0GT.pfm"], "kitti": ["000000_10.png", "000000_10_r.png"],
                     "left_right": ["my_left.jpg", "my_right.jpg"], "ambiguous": ["left_and_right.png", "right.png"]}.items():
    paths = [out / n for n in names]
    try:
        l = ns["_pick"](paths, ("left", "im0"), "left image"); r = ns["_pick"](paths, ("right", "im1"), "right image")
        pick[label] = {"left": l.name, "right": r.name}
    except Exception as exc:
        pick[label] = {"error": str(exc)[:200]}
res["P4_pick"] = pick
z = out / "evil.zip"
with zipfile.ZipFile(z, "w") as zf:
    zf.writestr("pairs.json", "[]"); zf.writestr("../escape.png", b"x")
try:
    ns["_safe_unzip"](z, out / "unz"); res["P4_safe_unzip"] = "extracted"
except Exception as exc:
    res["P4_safe_unzip"] = f"{type(exc).__name__}: {exc}"
(out / "results.json").write_text(json.dumps(res, indent=1, default=str))
print(json.dumps(res, indent=1, default=str))
